package com.example.h_ngm_n;

import static com.example.h_ngm_n.GameActivity.countImg;
import static com.example.h_ngm_n.GameActivity.drawables;
import static com.example.h_ngm_n.GameActivity.imageView;
import static com.example.h_ngm_n.GameActivity.tableAlphabet;
import static com.example.h_ngm_n.GameActivity.word;

import android.widget.Button;
import android.widget.TableRow;

public class Score {
    public static int counterForIncorrectButtons = 0; // нужно для подсчета ошибочных букв
    public static int counterForVictory = 0; // нужно для проверки на победу

    public static void checkVictory() {
        /* метод, проверяющий, отгадано ли слово */
        if (counterForVictory == word.length) {
            tableAlphabet.removeAllViews(); // удаление всех элементов из TableLayout
            GameActivity.textViewError.setText(R.string.text_view_victory);
            countImg = 0;
            GameActivity.letterCountAlphabet = 0;
            word = null;
            counterForVictory = 0;
            counterForIncorrectButtons = 0;
            Timer.running = false;
            /** ВОТ ЗДЕСЬ ДОЛЖНО БЫТЬ УВЕЛИЧЕНИЕ ПОВТОРЕНИЙ СЛОВА НА 1 */
        }
    }

    protected static void checkFailure() {
        /* метод, проверяющий, не проиграл ли игрок */
        if (Timer.seconds == 0 && !Timer.running || counterForIncorrectButtons == 10) {
            // если таймер остановился ИЛИ изображение виселицы последнее
            imageView.setImageDrawable(drawables[9]); // чтобы отразилось последнее изображение
            int index = 0;
            // в цикле происходит отображение всех непоказанных букв загаданного слова
            for (int i = 0; i < GameActivity.tableWord.getChildCount(); i++) {
                TableRow parentRow = (TableRow) GameActivity.tableWord.getChildAt(i);
                for (int j = 0; j < parentRow.getChildCount(); j++) {
                    Button b = (Button) parentRow.getChildAt(j);
                    b.setTextSize(24f);
                    b.setText(word[index]);
                    index++;
                }
            }
            // обнуление всех переменных
            tableAlphabet.removeAllViews(); // удаление всех элементов из TableLayout
            GameActivity.textViewError.setText(R.string.text_view_failure);
            countImg = 0;
            Timer.running = false;
            GameActivity.letterCountAlphabet = 0;
            counterForVictory = 0;
            counterForIncorrectButtons = 0;
        }
        if (countImg < 10) {
            // если изображение виселицы не последнее
            imageView.setImageDrawable(drawables[countImg]); // вызывается новое состояние виселицы
            countImg++;
            counterForIncorrectButtons++;
        }
    }
}
