package com.example.h_ngm_n;

import android.os.Handler;
import static com.example.h_ngm_n.GameActivity.textViewTimer;
import java.util.Locale;

public class Timer {
    protected static Handler handler;
    protected static int seconds = 0; // кол-во секунд для отгадывания
    protected static boolean running, wasRunning;

    protected static void runTimer(int frequency) {
        /* здесь запускается таймер на отгадывание английского слова */
        setSeconds(frequency); // определяем, сколько времени будет дано на отгадывание
        handler = new Handler();
        handler.post(new Runnable() {
            @Override
            public void run() {
                int minutes = (seconds % 3600) / 60;
                int secs = seconds % 60;
                String time = String.format(Locale.getDefault(),"%02d:%02d", minutes, secs);
                textViewTimer.setText(time);
                if (running && seconds>0) {
                    seconds--;
                    handler.postDelayed(this, 1000);
                } else {
                    running = false;
                    Score.checkFailure();
                }
            }
        });
    }

    private static void setSeconds(int freq){
        /* метод, который определяет сколько времени будет дано на отгадывания слова */
        if (freq < 4) {
            // если повторений было меньше 4
            switch (freq) {
                case 0: seconds = 300;break; // если еще не было повторений
                case 1: seconds = 240;break; // если было 1 повторение, то 4 минуты на отгадывание
                case 2: seconds = 180;break; // если было 2 повторения, то 3 минуты на отгадывание
                case 3: seconds = 120;break; // если было 3 повторения, то 2 минуты на отгадывание
            }
        } else seconds = 60; // после 4 повторений и больше дается только 1мин. на отгадывание
    }
}
