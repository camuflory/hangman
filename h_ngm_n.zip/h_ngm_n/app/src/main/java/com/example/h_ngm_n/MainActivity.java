package com.example.h_ngm_n;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Button buttonStartGame;
    private AssetManager assetManager;
    private final ArrayList<String> data = new ArrayList<>();
    private TextView textViewError;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonStartGame = findViewById(R.id.buttonStartPlay);
        textViewError = findViewById(R.id.textViewErrorMain);
        assetManager = getAssets();
        file();
    }


    public void startPlay(View view) {
        /** метод, начинающий Виселицу, если есть хотя бы 3 слова в словаре */
        if (data.size() < 3) {
            buttonStartGame.setClickable(false);
            textViewError.setText("Для начала игры необходимо иметь хотя бы 3 слова для заучивания");
        }
        Intent intent = new Intent(this, GameActivity.class);
        startActivity(intent);
    }

    public void addWord(View view) {
        /** метод, который перекидывает на другой экран, чтобы добавить слово/слова для заучивания */
        Intent intent = new Intent(this, DictionaryActivity.class);
        startActivity(intent);
    }

    private void file() {
        /* метод, который просто считывает файл */
        try (InputStream is = assetManager.open("dictionary.txt")){
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            while (reader.ready()) {
                data.add(reader.readLine());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}