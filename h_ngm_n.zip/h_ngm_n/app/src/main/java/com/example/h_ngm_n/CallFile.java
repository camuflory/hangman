package com.example.h_ngm_n;

import android.content.res.AssetManager;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class CallFile {
    public static AssetManager assetManager; // необходимо для обращения к текстовому файлу
    public static final ArrayList<String> words = new ArrayList<>(); // здесь будут все сроки из файла в формате "англСлово,перевод,кол-воПовторов"

    public static void readTheFile() {
        /* считывание слов из текстового файла */
        try (InputStream is = assetManager.open("dictionary.txt")) {
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            while (reader.ready()) {
                words.add(reader.readLine());
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void writeInFile(){
        /* метод, который записывает в файл данные */
    }
}
