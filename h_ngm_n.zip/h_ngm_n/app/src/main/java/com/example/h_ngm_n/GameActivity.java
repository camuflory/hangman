package com.example.h_ngm_n;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.content.res.AppCompatResources;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import java.util.Locale;

public class GameActivity extends AppCompatActivity {

    protected final char[] alphabet = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p',
            'q','r','s','t','u','v','x','w','y','z'}; // для алфавита на экране
    protected static int letterCountAlphabet = 0; // переменная для расставления букв алфавита по кнопкам
    protected static TableLayout tableAlphabet; // здесь будут TableRow с буквами на кнопках

    protected static Drawable[] drawables = new Drawable[10]; // массив изображений виселицы
    protected static final int ammountOfImg = 10; // кол-во изображений виселицы
    protected static int countImg = 0; // переменная - индекс для массива drawable

    private TextView textViewHint; // текстовое поле, на котором будут отображаться подсказки
    protected static TextView textViewTimer; // текстовое поле таймера

    protected static ImageView imageView; // изображение, на котором появляется состояние виселицы
    protected static TextView textViewError; // здесь будет указываться победа/проигрыш игрока
    protected static TableLayout tableWord; // слой для изображения черточек слова
    protected static String[] word; // массив из букв-строк загаданного слова
    private String[] data; // строка из англ. слова, его перевода и кол-ва повторений
    /** В МАССИВЕ DATA СТРОКИ БУДУТ ХРАНИТЬСЯ В ТАКОМ ФОРМАТЕ: data[0]-англ.слово,data[1]-перевод,data[2]-кол-во повторений*/
    private Button button; // кнопка, нажимая на которую появляется подсказка
    private int countLetterHint=0; // нужно для выставления букв в текстовом поле для подсказок

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        imageView = findViewById(R.id.imageView);
        tableAlphabet = findViewById(R.id.tableLayoutAlphabet);
        tableWord = findViewById(R.id.tableLayoutHiddenWord);
        textViewError = findViewById(R.id.textViewFailure);
        textViewTimer = findViewById(R.id.textViewTimer);
        textViewHint = findViewById(R.id.textViewHint);
        button = findViewById(R.id.buttonHint);

        CallFile.assetManager = getAssets(); // нужно для обращения к текстовому файлу
        tableAlphabet.setShrinkAllColumns(true); // чтобы кнопки не вылезли за края слоя
        tableAlphabet.setGravity(Gravity.CENTER); // чтобы кнопки плавали посередине столбца
        tableWord.setShrinkAllColumns(true);
        tableWord.setGravity(Gravity.CENTER);

        /* инициализация всех изображений в массив */
        for (int i = 0; i < drawables.length; i++) {
            drawables[i] = AppCompatResources.getDrawable(this, getResources()
                    .getIdentifier("h_"+ i, "drawable", getPackageName()));
        }

        /*нужно для сохранения времени таймера*/
        if (savedInstanceState != null) {
            Timer.seconds = savedInstanceState.getInt("seconds");
            Timer.running = savedInstanceState.getBoolean("running");
            Timer.wasRunning = savedInstanceState.getBoolean("wasRunning");
        }
        setAlphabet();
        CallFile.readTheFile();
        choiceRandomWord();
        Timer.running = true;
        Timer.runTimer(Integer.parseInt(data[2]));
    }

    /* для сохранения времени таймера в различных режимах телефона */
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putInt("seconds", Timer.seconds);
        savedInstanceState.putBoolean("running", Timer.running);
        savedInstanceState.putBoolean("wasRunning", Timer.wasRunning);
    }
    @Override
    protected void onPause() {
        super.onPause();
        Timer.wasRunning = Timer.running;
        Timer.running = false;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Timer.wasRunning) {
            Timer.running = true;
        }
    }

    private void setAlphabet() {
        /* инициализация кнопок с буквами алфавита */
        for (int i = 0; i < 4; i++) {
            TableRow tableRow = new TableRow(this);
            for (int j = 0; j < 6; j++) {
                Button button = new Button(this);
                button.setOnClickListener(this::onClickLetter); // программная установка onClick
                button.setText(String.valueOf(alphabet[letterCountAlphabet])); // ставим на кнопку букву алфавита
                button.setBackgroundResource(R.color.white);
                button.setTextSize(24f);
                letterCountAlphabet++;
                tableRow.addView(button);
            }
            tableRow.setGravity(Gravity.CENTER); // чтобы было посередине
            tableAlphabet.addView(tableRow);
        }
        /* а здесь добавляются две последние кноки с буквами алфавита */
        // я это вынесла отдельно, потому что через условие в основном цикле программа вылетала
        TableRow tableRow = new TableRow(this);
        for (int i = 0; i < 2; i++) {
            Button button = new Button(this);
            button.setOnClickListener(this::onClickLetter); // программная установка onClick
            button.setText(String.valueOf(alphabet[letterCountAlphabet]));
            button.setBackgroundResource(R.color.white);
            button.setTextSize(24f);
            letterCountAlphabet++;
            tableRow.addView(button);
        }
        tableRow.setGravity(Gravity.CENTER);
        tableAlphabet.addView(tableRow);
    }



    private void choiceRandomWord() {
        /* метод, выбирающий случайное слово для игры */
        int index = (int)(Math.random()*CallFile.words.size());
        data = CallFile.words.get(index).split(",");
        word = data[0].split("");
        /* здесь строка "_ " умножется на длинну перевода и после передается в текстовое поле в качестве подсказки*/
        textViewHint.setText(new String(new char[data[1].length()]).replace("\0", "_ "));
        setHiddenLetters();
    }

    private void setHiddenLetters() {
        /* метод, который создает кнопки в TableLayout, где будут буквы загаданного слова */
        TableRow tableRow1 = new TableRow(this), tableRow2 = new TableRow(this);
        tableRow1.setGravity(Gravity.CENTER);
        tableRow2.setGravity(Gravity.CENTER);
        for (int i = 0; i < word.length; i++) {
            Button button = new Button(this);
            button.setText("-");
            button.setTextSize(30f);
            button.setBackgroundResource(R.color.white);
            if (i<8) tableRow1.addView(button);
            else tableRow2.addView(button);
        }
        tableWord.addView(tableRow1);
        tableWord.addView(tableRow2);
    }

    public void onClickLetter(View view) {
        /** вот здесь вся суть игры */
        Button btn = (Button) view; // нужно для того, чтобы получить букву с кнопки
        String letter = btn.getText().toString().toLowerCase(Locale.ROOT); // буква с кнопки
        int index = 0; // переменная, благодаря которой находятся одинаковые/повторяющиеся буквы
        if (String.join("", word).contains(letter)) {
            // если буква есть в слове
            btn.setBackgroundResource(R.color.highlight);
            btn.setClickable(false); // чтобы не было повторений
            // обращение к нужной кнопке в tablelayout
            for (int i = 0; i < tableWord.getChildCount(); i++) {
                TableRow parentRow = (TableRow) tableWord.getChildAt(i);
                for (int j = 0; j < parentRow.getChildCount(); j++){
                    Button but = (Button) parentRow.getChildAt(j);
                    if(word[index].equals(letter)) {
                        // проходимся циклом по массиву кнопок слова, что бы найти нужную букву
                        Score.counterForVictory++;
                        but.setText(btn.getText().toString());
                        but.setTextSize(24f);
                        but.setBackgroundResource(R.color.highlight);
                    }
                    index++;
                }
            }
            Score.checkVictory();
        } else {
            // если буква неправильная
            btn.setBackgroundResource(R.color.error_color);
            btn.setClickable(false);
            Score.counterForIncorrectButtons++;
            Score.checkFailure();
        }
    }



    public void onButtonReset(View view) {
        /** метод, который запускает игру заново с новым словом */
        tableWord.removeAllViews();
        tableAlphabet.removeAllViews();
        textViewError.setText("");
        countImg = 0;
        letterCountAlphabet = 0;
        countLetterHint=0;
        button.setBackgroundResource(R.color.highlight);
        button.setClickable(true);
        word = null;
        Score.counterForVictory = 0;
        Score.counterForIncorrectButtons = 0;
        countLetterHint = 0;
        for (int i = 0; i < ammountOfImg; i++) {
            imageView.setImageDrawable(null);
        }
        setAlphabet();
        CallFile.readTheFile();
        choiceRandomWord();
        Timer.running = true;
        Timer.runTimer(Integer.parseInt(data[2]));
    }

    public void onButtonHint(View view) {
        /** метод, который дает подсказку в виде перевода загаданного слова */
        if (countLetterHint < 3) {
            // если кол-во попыток меньше 3
            // попытки всего 3, потому что минимальный перевод слова может сосотять из 3 букв
            countLetterHint++;
            // после каждого нажатия на кнопку для подсказки, таймер уменьшается на 10 секунд
            if (Timer.seconds > 10) Timer.seconds -= 10;
            // str - буквы (например было слово пар, counterForLetterHints=1, поэтому строка становится "п"
            String str = data[1].substring(0, countLetterHint);
            // lines - черточки "_ ", показывающие, сколько букв осталось в слове
            String lines = new String(new char[data[1].length()-str.length()]).replace("\0", "_ ");
            textViewHint.setText(str+lines);
        } else {
            // если количество попыток истекло
            button.setBackgroundColor(Color.WHITE);
            button.setClickable(false);
        }
    }
}