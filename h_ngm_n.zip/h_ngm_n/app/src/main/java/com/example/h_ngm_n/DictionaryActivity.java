package com.example.h_ngm_n;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;

public class DictionaryActivity extends AppCompatActivity {

    private EditText englishWord, translation;
    private TableLayout dictionary;
    private AssetManager assetManager;
    private TextView textViewError;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dictionary);

        assetManager = getAssets();

        englishWord = findViewById(R.id.EditTextEngWord);
        translation = findViewById(R.id.EditTextTranslation);
        dictionary = findViewById(R.id.tableLayoutMyDictionary);
        textViewError = findViewById(R.id.textViewError);

        readWordsFromFile();
    }

    public void onButtonBack(View view) {
        /** метод, который позволяет перейти на главный экран */
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    private void readWordsFromFile() {
        /* здесь происходит считывание слов из .txt файла и запись этих слов в таблицу на экране */
        try (InputStream is = assetManager.open("dictionary.txt")){
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            while (reader.ready()) {
                String[] data = reader.readLine().split(",");
                appendingOneToDictionary(data[0], data[1], data[2]);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void addWordAndTranslation(View view) {
        /** добавление слова и его перевода в текстовый файл НЕ РАБОТАЕТ!!! */
        try (FileOutputStream fos = new FileOutputStream("dictionary.txt",true);
             OutputStreamWriter osw = new OutputStreamWriter(fos, StandardCharsets.UTF_8)){
            if (englishWord.getText().toString().length()>2 && translation.getText().length() > 2) {
                // если длинна слова больше 2 символлов и длинна перевода больше 2 символов
                osw.write(englishWord+","+translation+","+"0"+"\n");
                appendingOneToDictionary(englishWord.getText().toString(),
                        translation.getText().toString(), "0");
            } else error();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void error() {
        /* метод, который будет указывать на ошибки пользователя */
        if (englishWord.getText().toString().equals("") && translation.getText().toString().equals("")) {
            textViewError.setText("Необходимо ввести английское слово и его перевод");
        } else if (englishWord.getText().toString().equals("")) {
            textViewError.setText("Необходимо ввести английское слово");
        } else if (translation.getText().toString().equals("")) {
            textViewError.setText("Необходимо ввести перевод слова");
        } if (englishWord.getText().toString().length()<2 &&
                translation.getText().toString().length()<2) {
            textViewError.setText("Длинна английского слова и его перевода должна быть больше 2 символов");
        } else if (englishWord.getText().toString().length()<2) {
            textViewError.setText("Длинна английского слова должна быть больше 2 символов");
        } else if (translation.getText().toString().length()<2) {
            textViewError.setText("Длинна перевода слова должна быть больше 2 символов");
        }

    }

    private void appendingOneToDictionary(String word, String translation, String frequency) {
        /* чтобы сократить код, этот метод добавляет одно слово с переводом в словарь-таблицу */
        TableRow tableRow = new TableRow(this);
        tableRow.setGravity(Gravity.CENTER);

        TextView textViewWord = new TextView(this); // поле для английского слова
        TextView textViewTran = new TextView(this); // поле для перевода
        TextView textViewFreq = new TextView(this); // поле для кол-ва повторений

        textViewWord.setTextSize(20f);
        textViewTran.setTextSize(20f);
        textViewFreq.setTextSize(20f);

        textViewWord.setText(word+" "); // пробелы нужны, чтобы поля не слипались
        textViewTran.setText(translation+" ");
        textViewFreq.setText(frequency);

        tableRow.addView(textViewWord);
        tableRow.addView(textViewTran);
        tableRow.addView(textViewFreq);

        dictionary.addView(tableRow);
    }
}